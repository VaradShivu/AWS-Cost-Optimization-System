const ctx=document.getElementById('costChart');

if(ctx){

new Chart(ctx,{

type:'line',

data:{

labels:['Jan','Feb','Mar','Apr','May','Jun'],

datasets:[{

label:'AWS Cost',

data:[2500,3200,2900,4100,3900,4700],

fill:false,

borderWidth:3

}]

}

});

}

const pie=document.getElementById('pieChart');

if(pie){

new Chart(pie,{

type:'pie',

data:{

labels:['EC2','S3','RDS','Lambda'],

datasets:[{

data:[45,20,15,20]

}]

}

});

}