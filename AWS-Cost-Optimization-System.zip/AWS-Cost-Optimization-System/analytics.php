<?php

require "config/session.php";
require "classes/CsvProcessor.php";

$processor = new CsvProcessor("uploads/aws_cost.csv");

$totalCost = $processor->totalCost();
$totalRecords = $processor->totalRecords();
$averageCost = $processor->averageCost();

$serviceWise = $processor->serviceWiseCost();
$regionWise = $processor->regionWiseCost();
$monthlyCost = $processor->monthlyCost();

$highestService = $processor->highestCostService();
$highestCost = $processor->highestCost();

$avgCPU = $processor->averageCPU();
$avgStorage = $processor->averageStorage();
$avgRequests = $processor->averageRequests();

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>AWS Analytics</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="sidebar">

<h3>

<i class="fa-solid fa-cloud"></i>

AWS Cost

</h3>

<a href="dashboard.php">

<i class="fa-solid fa-house"></i>

Dashboard

</a>

<a href="upload.php">

<i class="fa-solid fa-upload"></i>

Upload CSV

</a>

<a class="active" href="analytics.php">

<i class="fa-solid fa-chart-column"></i>

Analytics

</a>

<a href="forecast.php">

<i class="fa-solid fa-chart-line"></i>

Forecast

</a>

<a href="anomaly.php">

<i class="fa-solid fa-triangle-exclamation"></i>

Anomaly Detection

</a>

<a href="recommendation.php">

<i class="fa-solid fa-lightbulb"></i>

Recommendations

</a>

<a href="governance.php">

<i class="fa-solid fa-shield-halved"></i>

Governance

</a>

<a href="reports.php">

<i class="fa-solid fa-file-pdf"></i>

Reports

</a>

<a href="logout.php">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

<div class="main">

<nav class="topbar">

<h4>

AWS Cost Analytics

</h4>

</nav>

<div class="container-fluid mt-4">

<div class="row">

<div class="col-lg-3">

<div class="dashboard-card blue">

<i class="fa-solid fa-indian-rupee-sign"></i>

<h5>Total Cost</h5>

<h2>

₹<?php echo number_format($totalCost,2); ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card green">

<i class="fa-solid fa-chart-line"></i>

<h5>Average Cost</h5>

<h2>

₹<?php echo number_format($averageCost,2); ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card orange">

<i class="fa-solid fa-database"></i>

<h5>Total Records</h5>

<h2>

<?php echo $totalRecords; ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card red">

<i class="fa-solid fa-trophy"></i>

<h5>Highest Service</h5>

<h5>

<?php echo $highestService; ?>

</h5>

<p>

₹<?php echo number_format($highestCost,2); ?>

</p>

</div>

</div>

</div>

<div class="row mt-4">

<div class="col-lg-4">

<div class="dashboard-card purple">

<i class="fa-solid fa-microchip"></i>

<h5>Average CPU Usage</h5>

<h2>

<?php echo number_format($avgCPU,2); ?>%

</h2>

</div>

</div>

<div class="col-lg-4">

<div class="dashboard-card blue">

<i class="fa-solid fa-hard-drive"></i>

<h5>Average Storage</h5>

<h2>

<?php echo number_format($avgStorage,2); ?>

GB

</h2>

</div>

</div>

<div class="col-lg-4">

<div class="dashboard-card green">

<i class="fa-solid fa-network-wired"></i>

<h5>Average Requests</h5>

<h2>

<?php echo number_format($avgRequests,0); ?>

</h2>

</div>

</div>

</div>

<div class="row mt-4">

<div class="col-lg-8">

<div class="chart-box">

<h4>

Monthly AWS Cost Trend

</h4>

<canvas id="monthlyChart"></canvas>

</div>

</div>

<div class="col-lg-4">

<div class="chart-box">

<h4>

Region Distribution

</h4>

<canvas id="regionChart"></canvas>

</div>

</div>

</div>

<!-- ==========================================
SERVICE WISE COST
========================================== -->

<div class="row mt-4">

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-server"></i>

Top AWS Services

</h4>

<table class="table table-hover table-bordered">

<thead>

<tr>

<th>Rank</th>

<th>Service</th>

<th>Cost</th>

</tr>

</thead>

<tbody>

<?php

$rank = 1;

foreach($serviceWise as $service=>$cost)
{

    if($rank>10)
        break;

?>

<tr>

<td>

<?php echo $rank; ?>

</td>

<td>

<?php echo $service; ?>

</td>

<td>

₹<?php echo number_format($cost,2); ?>

</td>

</tr>

<?php

$rank++;

}

?>

</tbody>

</table>

</div>

</div>

<!-- ==========================================
REGION WISE COST
========================================== -->

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-earth-asia"></i>

Region Wise Cost

</h4>

<table class="table table-hover table-bordered">

<thead>

<tr>

<th>Rank</th>

<th>Region</th>

<th>Cost</th>

</tr>

</thead>

<tbody>

<?php

$rank = 1;

foreach($regionWise as $region=>$cost)
{

?>

<tr>

<td>

<?php echo $rank; ?>

</td>

<td>

<?php echo $region; ?>

</td>

<td>

₹<?php echo number_format($cost,2); ?>

</td>

</tr>

<?php

$rank++;

}

?>

</tbody>

</table>

</div>

</div>

</div>

<!-- ==========================================
SUMMARY
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-chart-pie"></i>

Cost Analysis Summary

</h4>

<div class="row">

<div class="col-md-4">

<div class="alert alert-primary">

<h5>

Highest Cost Service

</h5>

<p>

<strong>

<?php echo $highestService; ?>

</strong>

</p>

<p>

₹<?php echo number_format($highestCost,2); ?>

</p>

</div>

</div>

<div class="col-md-4">

<div class="alert alert-success">

<h5>

Average CPU Usage

</h5>

<p>

<strong>

<?php echo number_format($avgCPU,2); ?> %

</strong>

</p>

<p>

Resource utilization based on uploaded AWS report.

</p>

</div>

</div>

<div class="col-md-4">

<div class="alert alert-warning">

<h5>

Storage Usage

</h5>

<p>

<strong>

<?php echo number_format($avgStorage,2); ?>

GB

</strong>

</p>

<p>

Average storage consumed across services.

</p>

</div>

</div>

</div>

</div>

</div>

</div>

<!-- ==========================================
RECOMMENDATIONS
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-lightbulb text-warning"></i>

Optimization Recommendations

</h4>

<ul class="list-group">

<li class="list-group-item">

Review EC2 instances with CPU utilization below 20%.

</li>

<li class="list-group-item">

Move infrequently accessed S3 data to Glacier.

</li>

<li class="list-group-item">

Enable AWS Budgets and billing alerts for better cost control.

</li>

<li class="list-group-item">

Purchase Reserved Instances for long-running workloads.

</li>

<li class="list-group-item">

Delete unattached EBS volumes and unused snapshots.

</li>

<li class="list-group-item">

Use Auto Scaling to optimize compute costs during low traffic.

</li>

</ul>

</div>

</div>

</div>

<!-- ==========================================
FOOTER SUMMARY
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box text-center">

<h5>

AWS Cost Optimization & Intelligent Recommendation System

</h5>

<p class="text-muted">

Analytics generated from uploaded AWS Billing CSV

</p>

</div>

</div>

</div>

</div>

</div>

<?php

$serviceLabels = json_encode(array_keys($serviceWise));
$serviceValues = json_encode(array_values($serviceWise));

$regionLabels = json_encode(array_keys($regionWise));
$regionValues = json_encode(array_values($regionWise));

$monthLabels = json_encode(array_keys($monthlyCost));
$monthValues = json_encode(array_values($monthlyCost));

?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

// ========================================
// Monthly Cost Trend
// ========================================

const monthlyChart = document.getElementById("monthlyChart");

if(monthlyChart){

new Chart(monthlyChart,{

type:"line",

data:{

labels:<?php echo $monthLabels; ?>,

datasets:[{

label:"Monthly Cost",

data:<?php echo $monthValues; ?>,

fill:true,

tension:0.4,

borderWidth:3

}]

},

options:{

responsive:true,

plugins:{

legend:{

display:true

}

},

scales:{

y:{

beginAtZero:true

}

}

}

});

}

// ========================================
// Region Distribution
// ========================================

const regionChart = document.getElementById("regionChart");

if(regionChart){

new Chart(regionChart,{

type:"pie",

data:{

labels:<?php echo $regionLabels; ?>,

datasets:[{

data:<?php echo $regionValues; ?>

}]

},

options:{

responsive:true

}

});

}

</script>

<script src="assets/js/script.js"></script>

</body>

</html>