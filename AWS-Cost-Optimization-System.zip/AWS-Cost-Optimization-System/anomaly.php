<?php

require "config/session.php";
require "classes/CsvProcessor.php";

$processor = new CsvProcessor("uploads/aws_cost.csv");

$rows = $processor->getRows();

$totalCost = $processor->totalCost();
$averageCost = $processor->averageCost();

$highCostRecords = [];
$highCPURecords = [];
$highStorageRecords = [];

foreach($rows as $row)
{

    $cost = (float)$row["Cost"];
    $cpu = (float)$row["CPU_Usage"];
    $storage = (float)$row["Storage_GB"];

    if($cost > ($averageCost * 2))
    {
        $highCostRecords[] = $row;
    }

    if($cpu >= 85)
    {
        $highCPURecords[] = $row;
    }

    if($storage >= 400)
    {
        $highStorageRecords[] = $row;
    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Anomaly Detection</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="sidebar">

<h3>

<i class="fa-solid fa-cloud"></i>

AWS Cost

</h3>

<a href="dashboard.php">

<i class="fa-solid fa-house"></i>

Dashboard

</a>

<a href="upload.php">

<i class="fa-solid fa-upload"></i>

Upload CSV

</a>

<a href="analytics.php">

<i class="fa-solid fa-chart-column"></i>

Analytics

</a>

<a href="forecast.php">

<i class="fa-solid fa-chart-line"></i>

Forecast

</a>

<a class="active" href="anomaly.php">

<i class="fa-solid fa-triangle-exclamation"></i>

Anomaly Detection

</a>

<a href="recommendation.php">

<i class="fa-solid fa-lightbulb"></i>

Recommendations

</a>

<a href="governance.php">

<i class="fa-solid fa-shield-halved"></i>

Governance

</a>

<a href="reports.php">

<i class="fa-solid fa-file-pdf"></i>

Reports

</a>

<a href="logout.php">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

<div class="main">

<nav class="topbar">

<h4>

AWS Cost Anomaly Detection

</h4>

</nav>

<div class="container-fluid mt-4">

<div class="row">

<div class="col-lg-4">

<div class="dashboard-card red">

<i class="fa-solid fa-money-bill-trend-up"></i>

<h5>

High Cost Records

</h5>

<h2>

<?php echo count($highCostRecords); ?>

</h2>

</div>

</div>

<div class="col-lg-4">

<div class="dashboard-card orange">

<i class="fa-solid fa-microchip"></i>

<h5>

High CPU Usage

</h5>

<h2>

<?php echo count($highCPURecords); ?>

</h2>

</div>

</div>

<div class="col-lg-4">

<div class="dashboard-card purple">

<i class="fa-solid fa-hard-drive"></i>

<h5>

High Storage Usage

</h5>

<h2>

<?php echo count($highStorageRecords); ?>

</h2>

</div>

</div>

</div>

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

Detected High Cost Records

</h4>

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>Date</th>

<th>Service</th>

<th>Region</th>

<th>Cost</th>

<th>Severity</th>

</tr>

</thead>

<tbody>

<?php

foreach($highCostRecords as $row)
{

?>

<tr>

<td>

<?php echo $row["Date"]; ?>

</td>

<td>

<?php echo $row["Service"]; ?>

</td>

<td>

<?php echo $row["Region"]; ?>

</td>

<td>

₹<?php echo number_format($row["Cost"],2); ?>

</td>

<td>

<span class="badge bg-danger">

High

</span>

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

<!-- ==========================================
HIGH CPU USAGE
========================================== -->

<div class="row mt-4">

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-microchip text-warning"></i>

High CPU Usage

</h4>

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>Date</th>

<th>Service</th>

<th>CPU %</th>

<th>Status</th>

</tr>

</thead>

<tbody>

<?php

if(count($highCPURecords)==0)
{

?>

<tr>

<td colspan="4" class="text-center">

No High CPU Usage Detected

</td>

</tr>

<?php

}

else

{

foreach($highCPURecords as $row)
{

?>

<tr>

<td>

<?php echo $row["Date"]; ?>

</td>

<td>

<?php echo $row["Service"]; ?>

</td>

<td>

<?php echo $row["CPU_Usage"]; ?> %

</td>

<td>

<span class="badge bg-warning text-dark">

Medium

</span>

</td>

</tr>

<?php

}

}

?>

</tbody>

</table>

</div>

</div>

<!-- ==========================================
HIGH STORAGE
========================================== -->

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-hard-drive text-danger"></i>

High Storage Usage

</h4>

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>Date</th>

<th>Service</th>

<th>Storage</th>

<th>Status</th>

</tr>

</thead>

<tbody>

<?php

if(count($highStorageRecords)==0)
{

?>

<tr>

<td colspan="4" class="text-center">

No High Storage Usage Detected

</td>

</tr>

<?php

}

else

{

foreach($highStorageRecords as $row)
{

?>

<tr>

<td>

<?php echo $row["Date"]; ?>

</td>

<td>

<?php echo $row["Service"]; ?>

</td>

<td>

<?php echo $row["Storage_GB"]; ?>

GB

</td>

<td>

<span class="badge bg-danger">

High

</span>

</td>

</tr>

<?php

}

}

?>

</tbody>

</table>

</div>

</div>

</div>

<!-- ==========================================
RISK SUMMARY
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-shield-halved"></i>

Risk Assessment

</h4>

<div class="row">

<div class="col-md-4">

<div class="alert alert-danger">

<h5>

High Cost Alerts

</h5>

<p>

<?php echo count($highCostRecords); ?>

Records require immediate review.

</p>

</div>

</div>

<div class="col-md-4">

<div class="alert alert-warning">

<h5>

CPU Alerts

</h5>

<p>

<?php echo count($highCPURecords); ?>

Resources have unusually high CPU utilization.

</p>

</div>

</div>

<div class="col-md-4">

<div class="alert alert-info">

<h5>

Storage Alerts

</h5>

<p>

<?php echo count($highStorageRecords); ?>

Resources are consuming high storage.

</p>

</div>

</div>

</div>

</div>

</div>

</div>

<!-- ==========================================
AUTOMATIC RECOMMENDATIONS
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-lightbulb text-warning"></i>

Automatic Recommendations

</h4>

<div class="alert alert-success">

<ul class="mb-0">

<li>Review EC2 instances with consistently high CPU usage.</li>

<li>Delete unused EBS volumes and snapshots.</li>

<li>Move infrequently accessed S3 data to Glacier.</li>

<li>Configure AWS Budgets and Billing Alerts.</li>

<li>Enable Auto Scaling to reduce idle compute costs.</li>

<li>Consider Reserved Instances for long-running workloads.</li>

</ul>

</div>

</div>

</div>

</div>

<!-- ==========================================
ANOMALY SUMMARY CHART
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-chart-pie"></i>

Anomaly Summary

</h4>

<canvas id="anomalyChart"></canvas>

</div>

</div>

</div>

<!-- ==========================================
SYSTEM HEALTH
========================================== -->

<div class="row mt-4">

<div class="col-lg-4">

<div class="alert alert-success text-center">

<h5>

Overall System Health

</h5>

<h2>

<?php

$totalAlerts = count($highCostRecords) + count($highCPURecords) + count($highStorageRecords);

if($totalAlerts <= 5)
{
    echo "Excellent";
}
elseif($totalAlerts <= 15)
{
    echo "Good";
}
else
{
    echo "Needs Attention";
}

?>

</h2>

</div>

</div>

<div class="col-lg-4">

<div class="alert alert-primary text-center">

<h5>

Total Anomalies

</h5>

<h2>

<?php echo $totalAlerts; ?>

</h2>

</div>

</div>

<div class="col-lg-4">

<div class="alert alert-warning text-center">

<h5>

Recommendation

</h5>

<p class="mb-0">

Review high-cost resources weekly to reduce unnecessary AWS spending.

</p>

</div>

</div>

</div>

<!-- ==========================================
FOOTER
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box text-center">

<h5>

AWS Cost Optimization & Intelligent Recommendation System

</h5>

<p class="text-muted">

Anomaly Detection Module • Generated from uploaded AWS Billing CSV

</p>

</div>

</div>

</div>

</div>

</div>

<?php

$chartLabels = json_encode([
    "High Cost",
    "High CPU",
    "High Storage"
]);

$chartValues = json_encode([
    count($highCostRecords),
    count($highCPURecords),
    count($highStorageRecords)
]);

?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

const anomalyCanvas = document.getElementById("anomalyChart");

if(anomalyCanvas){

new Chart(anomalyCanvas,{

type:"bar",

data:{

labels:<?php echo $chartLabels; ?>,

datasets:[{

label:"Detected Anomalies",

data:<?php echo $chartValues; ?>,

borderWidth:1

}]

},

options:{

responsive:true,

plugins:{

legend:{

display:false

}

},

scales:{

y:{

beginAtZero:true,

ticks:{

precision:0

}

}

}

}

});

}

</script>

<script src="assets/js/script.js"></script>

</body>

</html>