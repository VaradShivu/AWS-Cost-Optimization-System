<?php

require "config/session.php";
require "classes/CsvProcessor.php";

$processor = new CsvProcessor("uploads/aws_cost.csv");

$totalCost = $processor->totalCost();
$totalRecords = $processor->totalRecords();
$averageCost = $processor->averageCost();

$serviceWise = $processor->serviceWiseCost();
$regionWise = $processor->regionWiseCost();
$monthlyCost = $processor->monthlyCost();

$highestService = $processor->highestCostService();
$highestCost = $processor->highestCost();

$avgCPU = $processor->averageCPU();
$avgStorage = $processor->averageStorage();
$avgRequests = $processor->averageRequests();

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>AWS Reports</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="sidebar">

<h3>

<i class="fa-solid fa-cloud"></i>

AWS Cost

</h3>

<a href="dashboard.php">

<i class="fa-solid fa-house"></i>

Dashboard

</a>

<a href="upload.php">

<i class="fa-solid fa-upload"></i>

Upload CSV

</a>

<a href="analytics.php">

<i class="fa-solid fa-chart-column"></i>

Analytics

</a>

<a href="forecast.php">

<i class="fa-solid fa-chart-line"></i>

Forecast

</a>

<a href="anomaly.php">

<i class="fa-solid fa-triangle-exclamation"></i>

Anomaly Detection

</a>

<a href="recommendation.php">

<i class="fa-solid fa-lightbulb"></i>

Recommendations

</a>

<a href="governance.php">

<i class="fa-solid fa-shield-halved"></i>

Governance

</a>

<a class="active" href="reports.php">

<i class="fa-solid fa-file-pdf"></i>

Reports

</a>

<a href="logout.php">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

<div class="main">

<nav class="topbar">

<h4>

AWS Cost Optimization Report

</h4>

<div>

<button onclick="window.print()" class="btn btn-success">

<i class="fa-solid fa-print"></i>

Print Report

</button>

</div>

</nav>

<div class="container-fluid mt-4">

<!-- SUMMARY CARDS -->

<div class="row">

<div class="col-lg-3">

<div class="dashboard-card blue">

<i class="fa-solid fa-indian-rupee-sign"></i>

<h5>Total Cost</h5>

<h2>

₹<?php echo number_format($totalCost,2); ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card green">

<i class="fa-solid fa-chart-simple"></i>

<h5>Average Cost</h5>

<h2>

₹<?php echo number_format($averageCost,2); ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card orange">

<i class="fa-solid fa-database"></i>

<h5>Total Records</h5>

<h2>

<?php echo $totalRecords; ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card red">

<i class="fa-solid fa-trophy"></i>

<h5>Highest Cost Service</h5>

<h5>

<?php echo $highestService; ?>

</h5>

<p>

₹<?php echo number_format($highestCost,2); ?>

</p>

</div>

</div>

</div>

<!-- EXECUTIVE SUMMARY -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h3>

Executive Summary

</h3>

<p>

This report provides a consolidated analysis of AWS billing data uploaded into the AWS Cost Optimization System.

It summarizes total expenditure, service utilization, resource statistics, recommendations, governance status, and optimization opportunities.

</p>

</div>

</div>

</div>

<!-- REPORT CHART -->

<div class="row mt-4">

<div class="col-lg-8">

<div class="chart-box">

<h4>

Monthly Cost Trend

</h4>

<canvas id="reportChart"></canvas>

</div>

</div>

<div class="col-lg-4">

<div class="chart-box">

<h4>

Infrastructure Summary

</h4>

<table class="table">

<tr>

<th>Average CPU</th>

<td>

<?php echo number_format($avgCPU,2); ?> %

</td>

</tr>

<tr>

<th>Average Storage</th>

<td>

<?php echo number_format($avgStorage,2); ?>

GB

</td>

</tr>

<tr>

<th>Average Requests</th>

<td>

<?php echo number_format($avgRequests); ?>

</td>

</tr>

<tr>

<th>Total Services</th>

<td>

<?php echo count($serviceWise); ?>

</td>

</tr>

</table>

</div>

</div>

</div>

<!-- ==========================================
SERVICE COST REPORT
========================================== -->

<div class="row mt-4">

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-server"></i>

Top AWS Services

</h4>

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>Rank</th>

<th>Service</th>

<th>Total Cost</th>

</tr>

</thead>

<tbody>

<?php

$rank = 1;

foreach($serviceWise as $service=>$cost)
{

if($rank>10)
break;

?>

<tr>

<td>

<?php echo $rank; ?>

</td>

<td>

<?php echo $service; ?>

</td>

<td>

₹<?php echo number_format($cost,2); ?>

</td>

</tr>

<?php

$rank++;

}

?>

</tbody>

</table>

</div>

</div>

<!-- ==========================================
REGION REPORT
========================================== -->

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-earth-asia"></i>

Region-wise Cost

</h4>

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>Region</th>

<th>Total Cost</th>

</tr>

</thead>

<tbody>

<?php

foreach($regionWise as $region=>$cost)
{

?>

<tr>

<td>

<?php echo $region; ?>

</td>

<td>

₹<?php echo number_format($cost,2); ?>

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

<!-- ==========================================
RECOMMENDATION SUMMARY
========================================== -->

<div class="row mt-4">

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-lightbulb text-warning"></i>

Recommendation Summary

</h4>

<ul class="list-group">

<li class="list-group-item">

Resize underutilized EC2 instances.

</li>

<li class="list-group-item">

Purchase Reserved Instances for long-running workloads.

</li>

<li class="list-group-item">

Archive S3 data to Glacier.

</li>

<li class="list-group-item">

Delete unattached EBS volumes.

</li>

<li class="list-group-item">

Enable AWS Budgets and billing alerts.

</li>

<li class="list-group-item">

Configure Auto Scaling policies.

</li>

</ul>

</div>

</div>

<!-- ==========================================
ANOMALY SUMMARY
========================================== -->

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-triangle-exclamation text-danger"></i>

Anomaly Summary

</h4>

<table class="table table-bordered">

<tr>

<th>High Cost Risk</th>

<td>

Medium

</td>

</tr>

<tr>

<th>CPU Utilization</th>

<td>

<?php echo number_format($avgCPU,2); ?> %

</td>

</tr>

<tr>

<th>Storage Utilization</th>

<td>

<?php echo number_format($avgStorage,2); ?> GB

</td>

</tr>

<tr>

<th>Risk Status</th>

<td>

<span class="badge bg-warning text-dark">

Needs Monitoring

</span>

</td>

</tr>

</table>

</div>

</div>

</div>

<!-- ==========================================
GOVERNANCE SUMMARY
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-shield-halved text-success"></i>

Governance Summary

</h4>

<table class="table table-bordered">

<thead>

<tr>

<th>Category</th>

<th>Status</th>

<th>Remarks</th>

</tr>

</thead>

<tbody>

<tr>

<td>

Cost Governance

</td>

<td>

<span class="badge bg-success">

Good

</span>

</td>

<td>

Budget monitoring is active.

</td>

</tr>

<tr>

<td>

Security

</td>

<td>

<span class="badge bg-warning text-dark">

Review

</span>

</td>

<td>

Enable MFA for all IAM users.

</td>

</tr>

<tr>

<td>

Storage Governance

</td>

<td>

<span class="badge bg-primary">

Normal

</span>

</td>

<td>

Archive old data regularly.

</td>

</tr>

<tr>

<td>

Resource Utilization

</td>

<td>

<span class="badge bg-success">

Healthy

</span>

</td>

<td>

Resources are operating normally.

</td>

</tr>

</tbody>

</table>

</div>

</div>

</div>

<!-- ==========================================
REPORT CHARTS
========================================== -->

<div class="row mt-4">

<div class="col-lg-8">

<div class="chart-box">

<h4>

<i class="fa-solid fa-chart-line"></i>

Monthly AWS Cost Trend

</h4>

<canvas id="monthlyChart"></canvas>

</div>

</div>

<div class="col-lg-4">

<div class="chart-box">

<h4>

<i class="fa-solid fa-chart-pie"></i>

Service Distribution

</h4>

<canvas id="serviceChart"></canvas>

</div>

</div>

</div>

<!-- ==========================================
FINAL REPORT STATUS
========================================== -->

<div class="row mt-4">

<div class="col-lg-3">

<div class="alert alert-success text-center">

<h5>

Overall Status

</h5>

<h2>

Healthy

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="alert alert-primary text-center">

<h5>

Total Services

</h5>

<h2>

<?php echo count($serviceWise); ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="alert alert-warning text-center">

<h5>

Optimization Ready

</h5>

<h2>

Yes

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="alert alert-danger text-center">

<h5>

Estimated Savings

</h5>

<h2>

₹<?php echo number_format($totalCost*0.18,2); ?>

</h2>

</div>

</div>

</div>

<!-- ==========================================
FOOTER
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box text-center">

<h4>

AWS Cost Optimization & Intelligent Recommendation System

</h4>

<p class="text-muted">

Final Report generated on

<strong>

<?php echo date("d M Y h:i A"); ?>

</strong>

</p>

<p>

Developed using

PHP • HTML • CSS • JavaScript • Bootstrap • Chart.js

</p>

</div>

</div>

</div>

</div>

</div>

<?php

$monthLabels = json_encode(array_keys($monthlyCost));
$monthValues = json_encode(array_values($monthlyCost));

$serviceLabels = json_encode(array_keys($serviceWise));
$serviceValues = json_encode(array_values($serviceWise));

?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

// ========================================
// Monthly Trend
// ========================================

const monthlyCanvas = document.getElementById("monthlyChart");

if(monthlyCanvas){

new Chart(monthlyCanvas,{

type:"line",

data:{

labels:<?php echo $monthLabels; ?>,

datasets:[{

label:"Monthly AWS Cost",

data:<?php echo $monthValues; ?>,

fill:true,

tension:0.4,

borderWidth:3,

pointRadius:5

}]

},

options:{

responsive:true,

plugins:{

legend:{

display:true

}

},

scales:{

y:{

beginAtZero:true

}

}

}

});

}

// ========================================
// Service Distribution
// ========================================

const serviceCanvas = document.getElementById("serviceChart");

if(serviceCanvas){

new Chart(serviceCanvas,{

type:"doughnut",

data:{

labels:<?php echo $serviceLabels; ?>,

datasets:[{

data:<?php echo $serviceValues; ?>

}]

},

options:{

responsive:true,

cutout:"60%"

}

});

}

</script>

<script src="assets/js/script.js"></script>

</body>

</html>