<?php

require "config/session.php";

$message = "";
$type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (!isset($_FILES["csv"])) {

        $message = "Please select a CSV file.";
        $type = "danger";

    } else {

        $file = $_FILES["csv"];

        if ($file["error"] != UPLOAD_ERR_OK) {

            $message = "File upload failed.";
            $type = "danger";

        } else {

            $extension = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));

            if ($extension != "csv") {

                $message = "Only CSV files are allowed.";
                $type = "danger";

            } else {

                $destination = "uploads/aws_cost.csv";

                if (move_uploaded_file($file["tmp_name"], $destination)) {

                    $message = "CSV uploaded successfully.";
                    $type = "success";

                } else {

                    $message = "Unable to save the uploaded file.";
                    $type = "danger";

                }

            }

        }

    }

}

$fileExists = file_exists("uploads/aws_cost.csv");

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Upload AWS CSV</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="sidebar">

<h3>

<i class="fa-solid fa-cloud"></i>

AWS Cost

</h3>

<a href="dashboard.php">

<i class="fa-solid fa-house"></i>

Dashboard

</a>

<a class="active" href="upload.php">

<i class="fa-solid fa-upload"></i>

Upload CSV

</a>

<a href="analytics.php">

<i class="fa-solid fa-chart-column"></i>

Analytics

</a>

<a href="forecast.php">

<i class="fa-solid fa-chart-line"></i>

Forecast

</a>

<a href="anomaly.php">

<i class="fa-solid fa-triangle-exclamation"></i>

Anomaly Detection

</a>

<a href="recommendation.php">

<i class="fa-solid fa-lightbulb"></i>

Recommendations

</a>

<a href="governance.php">

<i class="fa-solid fa-shield-halved"></i>

Governance

</a>

<a href="reports.php">

<i class="fa-solid fa-file-pdf"></i>

Reports

</a>

<a href="logout.php">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

<div class="main">

<nav class="topbar">

<h4>

Upload AWS Billing CSV

</h4>

</nav>

<div class="container-fluid mt-4">

<div class="row justify-content-center">

<div class="col-lg-8">

<div class="upload-card">

<h3 class="mb-4">

<i class="fa-solid fa-file-csv text-success"></i>

Upload Billing Report

</h3>

<?php if($message!=""){ ?>

<div class="alert alert-<?php echo $type; ?>">

<?php echo $message; ?>

</div>

<?php } ?>

<form method="POST" enctype="multipart/form-data">

<div class="mb-4">

<label class="form-label">

Choose CSV File

</label>

<input

type="file"

name="csv"

accept=".csv"

class="form-control"

required>

</div>

<div class="d-grid">

<button class="btn btn-primary btn-lg">

<i class="fa-solid fa-cloud-arrow-up"></i>

Upload CSV

</button>

</div>

</form>

<hr>

<?php if($fileExists){ ?>

<h5>

Current Uploaded File

</h5>

<table class="table table-bordered mt-3">

<tr>

<th>File Name</th>

<td>aws_cost.csv</td>

</tr>

<tr>

<th>File Size</th>

<td>

<?php

echo round(filesize("uploads/aws_cost.csv")/1024,2);

?>

KB

</td>

</tr>

<tr>

<th>Last Modified</th>

<td>

<?php

echo date("d M Y h:i A",filemtime("uploads/aws_cost.csv"));

?>

</td>

</tr>

</table>

<div class="mt-3">

<a href="dashboard.php" class="btn btn-success">

<i class="fa-solid fa-gauge-high"></i>

Go to Dashboard

</a>

<a href="analytics.php" class="btn btn-primary">

<i class="fa-solid fa-chart-column"></i>

View Analytics

</a>

</div>

<?php } ?>

</div>

</div>

</div>

</div>

</div>

<script src="assets/js/script.js"></script>

</body>

</html>