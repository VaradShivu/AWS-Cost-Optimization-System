<?php

/*
=========================================
AWS Cost Optimization System
Session Management
=========================================
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once "auth.php";

/*
|--------------------------------------------------------------------------
| Check Login
|--------------------------------------------------------------------------
|
| Every protected page should include:
|
| require "config/session.php";
|
*/

if (!isLoggedIn()) {

    header("Location: login.php");
    exit();

}

/*
|--------------------------------------------------------------------------
| Current User
|--------------------------------------------------------------------------
*/

$currentUser = currentUser();

/*
|--------------------------------------------------------------------------
| Timeout (Optional)
|--------------------------------------------------------------------------
|
| Automatically logout after 30 minutes of inactivity.
|
*/

$timeout = 1800; // 30 Minutes

if (isset($_SESSION["LAST_ACTIVITY"])) {

    if ((time() - $_SESSION["LAST_ACTIVITY"]) > $timeout) {

        session_unset();
        session_destroy();

        header("Location: login.php?timeout=1");
        exit();

    }

}

$_SESSION["LAST_ACTIVITY"] = time();

?>