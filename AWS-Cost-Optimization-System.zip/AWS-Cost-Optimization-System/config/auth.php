<?php

/*
=========================================
AWS Cost Optimization System
Authentication Module
=========================================
*/

function getUsers()
{
    $file = "data/users.json";

    if (!file_exists($file)) {
        return [];
    }

    $json = file_get_contents($file);

    $users = json_decode($json, true);

    if (!is_array($users)) {
        return [];
    }

    return $users;
}

function login($username, $password)
{
    $users = getUsers();

    foreach ($users as $user) {

        if (
            strtolower(trim($user["username"])) == strtolower(trim($username))
            &&
            trim($user["password"]) == trim($password)
        ) {

            return [
                "username" => $user["username"],
                "name" => $user["name"]
            ];

        }

    }

    return false;
}

function isLoggedIn()
{
    return isset($_SESSION["user"]);
}

function currentUser()
{
    if(isset($_SESSION["user"]))
    {
        return $_SESSION["user"];
    }

    return null;
}