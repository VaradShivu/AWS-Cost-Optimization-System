<?php

require "config/session.php";
require "classes/CsvProcessor.php";

$processor = new CsvProcessor("uploads/aws_cost.csv");

$monthlyCost = $processor->monthlyCost();
$totalCost = $processor->totalCost();

$months = array_keys($monthlyCost);
$values = array_values($monthlyCost);

$averageMonthly = 0;
$forecastCost = 0;
$growthRate = 5;

if(count($values) > 0)
{
    $averageMonthly = array_sum($values) / count($values);

    // Simple 5% growth forecast
    $forecastCost = $averageMonthly * (1 + ($growthRate / 100));
}

$savingsTarget = $forecastCost * 0.15;

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Forecast</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="sidebar">

<h3>

<i class="fa-solid fa-cloud"></i>

AWS Cost

</h3>

<a href="dashboard.php">

<i class="fa-solid fa-house"></i>

Dashboard

</a>

<a href="upload.php">

<i class="fa-solid fa-upload"></i>

Upload CSV

</a>

<a href="analytics.php">

<i class="fa-solid fa-chart-column"></i>

Analytics

</a>

<a class="active" href="forecast.php">

<i class="fa-solid fa-chart-line"></i>

Forecast

</a>

<a href="anomaly.php">

<i class="fa-solid fa-triangle-exclamation"></i>

Anomaly Detection

</a>

<a href="recommendation.php">

<i class="fa-solid fa-lightbulb"></i>

Recommendations

</a>

<a href="governance.php">

<i class="fa-solid fa-shield-halved"></i>

Governance

</a>

<a href="reports.php">

<i class="fa-solid fa-file-pdf"></i>

Reports

</a>

<a href="logout.php">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

<div class="main">

<nav class="topbar">

<h4>

AWS Cost Forecast

</h4>

</nav>

<div class="container-fluid mt-4">

<div class="row">

<div class="col-lg-3">

<div class="dashboard-card blue">

<i class="fa-solid fa-wallet"></i>

<h5>Current Total Cost</h5>

<h2>

₹<?php echo number_format($totalCost,2); ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card green">

<i class="fa-solid fa-chart-line"></i>

<h5>Average Monthly Cost</h5>

<h2>

₹<?php echo number_format($averageMonthly,2); ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card orange">

<i class="fa-solid fa-arrow-trend-up"></i>

<h5>Predicted Next Month</h5>

<h2>

₹<?php echo number_format($forecastCost,2); ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card red">

<i class="fa-solid fa-piggy-bank"></i>

<h5>Potential Savings</h5>

<h2>

₹<?php echo number_format($savingsTarget,2); ?>

</h2>

</div>

</div>

</div>

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

Forecast Trend

</h4>

<canvas id="forecastChart"></canvas>

</div>

</div>

</div>

<!-- ==========================================
FORECAST SUMMARY
========================================== -->

<div class="row mt-4">

<div class="col-lg-8">

<div class="chart-box">

<h4>

<i class="fa-solid fa-chart-column"></i>

Forecast Summary

</h4>

<table class="table table-bordered">

<tr>

<th>Total AWS Cost</th>

<td>

₹<?php echo number_format($totalCost,2); ?>

</td>

</tr>

<tr>

<th>Average Monthly Cost</th>

<td>

₹<?php echo number_format($averageMonthly,2); ?>

</td>

</tr>

<tr>

<th>Growth Assumption</th>

<td>

<?php echo $growthRate; ?> %

</td>

</tr>

<tr>

<th>Predicted Next Month Cost</th>

<td>

₹<?php echo number_format($forecastCost,2); ?>

</td>

</tr>

<tr>

<th>Potential Savings</th>

<td>

₹<?php echo number_format($savingsTarget,2); ?>

</td>

</tr>

</table>

</div>

</div>

<div class="col-lg-4">

<div class="chart-box">

<h4>

<i class="fa-solid fa-bullseye"></i>

Budget Status

</h4>

<?php

if($forecastCost <= $averageMonthly)
{

?>

<div class="alert alert-success">

<h5>

Budget Stable

</h5>

<p>

Predicted spending is within the expected monthly range.

</p>

</div>

<?php

}
else
{

?>

<div class="alert alert-warning">

<h5>

Budget Increase Expected

</h5>

<p>

Estimated spending is expected to increase next month.

</p>

</div>

<?php

}

?>

<div class="alert alert-info">

<strong>Estimated Growth</strong>

<br><br>

<?php echo $growthRate; ?> %

</div>

<div class="alert alert-primary">

<strong>Target Savings</strong>

<br><br>

₹<?php echo number_format($savingsTarget,2); ?>

</div>

</div>

</div>

</div>

<!-- ==========================================
MONTHLY HISTORY
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-calendar-days"></i>

Monthly Cost History

</h4>

<table class="table table-hover table-bordered">

<thead>

<tr>

<th>Month</th>

<th>AWS Cost</th>

</tr>

</thead>

<tbody>

<?php

foreach($monthlyCost as $month=>$cost)
{

?>

<tr>

<td>

<?php echo $month; ?>

</td>

<td>

₹<?php echo number_format($cost,2); ?>

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>

</div>

<!-- ==========================================
OPTIMIZATION SUGGESTIONS
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-lightbulb text-warning"></i>

Forecast Recommendations

</h4>

<div class="row">

<div class="col-md-4">

<div class="alert alert-success">

<h5>

Reserved Instances

</h5>

<p>

Purchase Reserved Instances for continuously running EC2 workloads to reduce future compute costs.

</p>

</div>

</div>

<div class="col-md-4">

<div class="alert alert-warning">

<h5>

Storage Optimization

</h5>

<p>

Archive old S3 objects to Glacier and delete unused EBS snapshots.

</p>

</div>

</div>

<div class="col-md-4">

<div class="alert alert-info">

<h5>

Auto Scaling

</h5>

<p>

Use Auto Scaling Groups to automatically adjust resources according to workload.

</p>

</div>

</div>

</div>

</div>

</div>

</div>

<!-- ==========================================
FOOTER
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box text-center">

<h5>

AWS Cost Forecast Report

</h5>

<p class="text-muted">

Forecast generated using historical AWS billing data and a simple growth model.

</p>

</div>

</div>

</div>

</div>

</div>

<?php

$monthLabels = json_encode(array_keys($monthlyCost));
$monthValues = json_encode(array_values($monthlyCost));

$forecastLabels = array_keys($monthlyCost);
$forecastValues = array_values($monthlyCost);

// Add forecast point
$forecastLabels[] = "Next Month";
$forecastValues[] = round($forecastCost, 2);

?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

const forecastChart = document.getElementById("forecastChart");

if(forecastChart){

new Chart(forecastChart,{

type:"line",

data:{

labels:<?php echo json_encode($forecastLabels); ?>,

datasets:[{

label:"AWS Cost Forecast",

data:<?php echo json_encode($forecastValues); ?>,

fill:true,

tension:0.35,

borderWidth:3,

pointRadius:5

}]

},

options:{

responsive:true,

plugins:{

legend:{

display:true

}

},

scales:{

y:{

beginAtZero:true,

title:{

display:true,

text:"Cost (₹)"

}

},

x:{

title:{

display:true,

text:"Month"

}

}

}

}

});

}

</script>

<script src="assets/js/script.js"></script>

</body>

</html>