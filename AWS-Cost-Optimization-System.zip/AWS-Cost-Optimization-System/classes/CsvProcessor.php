<?php

class CsvProcessor
{
    private $file;
    private $rows = [];

    public function __construct($file)
    {
        $this->file = $file;

        if(file_exists($file))
        {
            $this->loadCSV();
        }
    }

    /* ===========================================
       LOAD CSV
    =========================================== */

    private function loadCSV()
    {
        $handle = fopen($this->file,"r");

        if(!$handle)
            return;

        $header = fgetcsv($handle);

        if(!$header)
        {
            fclose($handle);
            return;
        }

        // Detect delimiter
        if(count($header)==1)
        {
            rewind($handle);
            $header = fgetcsv($handle,0,";");
            $delimiter=";";
        }
        else
        {
            $delimiter=",";
        }

        $header[0]=preg_replace('/^\xEF\xBB\xBF/','',$header[0]);

        $header=array_map('trim',$header);

        while(($data=fgetcsv($handle,0,$delimiter))!==false)
        {

            if(count(array_filter($data))==0)
                continue;

            if(count($header)!=count($data))
                continue;

            $data=array_map('trim',$data);

            $this->rows[]=array_combine($header,$data);

        }

        fclose($handle);
    }

    /* ===========================================
       PRIVATE HELPER
    =========================================== */

    private function value($row,$column)
    {
        foreach($row as $key=>$value)
        {
            if(strcasecmp(trim($key),trim($column))==0)
            {
                return $value;
            }
        }

        return "";
    }

    /* ===========================================
       BASIC
    =========================================== */

    public function getRows()
    {
        return $this->rows;
    }

    public function totalRecords()
    {
        return count($this->rows);
    }

    public function totalCost()
    {
        $total=0;

        foreach($this->rows as $row)
        {
            $total+=(float)$this->value($row,"Cost");
        }

        return round($total,2);
    }

    public function averageCost()
    {
        if($this->totalRecords()==0)
            return 0;

        return round($this->totalCost()/$this->totalRecords(),2);
    }

    /* ===========================================
       SERVICE ANALYSIS
    =========================================== */

    public function serviceWiseCost()
    {
        $services=[];

        foreach($this->rows as $row)
        {

            $service=$this->value($row,"Service");

            if($service=="")
                $service="Unknown";

            if(!isset($services[$service]))
                $services[$service]=0;

            $services[$service]+=(float)$this->value($row,"Cost");

        }

        arsort($services);

        return $services;
    }

    public function topServices($limit=5)
    {
        return array_slice(
            $this->serviceWiseCost(),
            0,
            $limit,
            true
        );
    }

    public function highestCostService()
    {
        $services=$this->serviceWiseCost();

        if(empty($services))
            return "N/A";

        return array_key_first($services);
    }

    public function highestCost()
    {
        $services=$this->serviceWiseCost();

        if(empty($services))
            return 0;

        return reset($services);
    }

    /* ===========================================
       REGION ANALYSIS
    =========================================== */

    public function regionWiseCost()
    {
        $regions=[];

        foreach($this->rows as $row)
        {

            $region=$this->value($row,"Region");

            if($region=="")
                $region="Unknown";

            if(!isset($regions[$region]))
                $regions[$region]=0;

            $regions[$region]+=(float)$this->value($row,"Cost");

        }

        arsort($regions);

        return $regions;
    }

    public function topRegions($limit=5)
    {
        return array_slice(
            $this->regionWiseCost(),
            0,
            $limit,
            true
        );
    }

    /* ===========================================
       MONTHLY ANALYSIS
    =========================================== */

    public function monthlyCost()
    {
        $months=[];

        foreach($this->rows as $row)
        {

            $date=$this->value($row,"Date");

            if($date=="")
                continue;

            $month=date("M",strtotime($date));

            if(!isset($months[$month]))
                $months[$month]=0;

            $months[$month]+=(float)$this->value($row,"Cost");

        }

        return $months;
    }

    /* ===========================================
       CPU
    =========================================== */

    public function averageCPU()
    {
        $sum=0;
        $count=0;

        foreach($this->rows as $row)
        {
            $cpu=(float)$this->value($row,"CPU_Usage");

            if($cpu>0)
            {
                $sum+=$cpu;
                $count++;
            }
        }

        if($count==0)
            return 0;

        return round($sum/$count,2);
    }

    /* ===========================================
       STORAGE
    =========================================== */

    public function averageStorage()
    {
        $sum=0;
        $count=0;

        foreach($this->rows as $row)
        {
            $storage=(float)$this->value($row,"Storage_GB");

            if($storage>0)
            {
                $sum+=$storage;
                $count++;
            }
        }

        if($count==0)
            return 0;

        return round($sum/$count,2);
    }

    /* ===========================================
       REQUESTS
    =========================================== */

    public function averageRequests()
    {
        $sum=0;
        $count=0;

        foreach($this->rows as $row)
        {
            $req=(float)$this->value($row,"Requests");

            if($req>0)
            {
                $sum+=$req;
                $count++;
            }
        }

        if($count==0)
            return 0;

        return round($sum/$count,2);
    }

    /* ===========================================
       LOWEST COST
    =========================================== */

    public function lowestCostRecord()
    {

        if(empty($this->rows))
            return [];

        $lowest=$this->rows[0];

        foreach($this->rows as $row)
        {

            if(
                (float)$this->value($row,"Cost")
                <
                (float)$this->value($lowest,"Cost")
            )
            {
                $lowest=$row;
            }

        }

        return $lowest;

    }

}