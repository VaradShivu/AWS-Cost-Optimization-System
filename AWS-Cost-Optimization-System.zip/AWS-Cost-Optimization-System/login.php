<?php

session_start();

if (isset($_SESSION['user'])) {
    header("Location: dashboard.php");
    exit();
}

require_once "config/auth.php";

$error = "";
$success = "";

if (isset($_GET["logout"])) {
    $success = "You have been logged out successfully.";
}

if (isset($_GET["timeout"])) {
    $error = "Your session expired. Please login again.";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    if ($username == "" || $password == "") {

        $error = "Please enter Username and Password.";

    } else {

        $user = login($username, $password);

        if ($user) {

            $_SESSION["user"] = $user;

            header("Location: dashboard.php");
            exit();

        } else {

            $error = "Invalid Username or Password.";

        }

    }

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>AWS Cost Optimization System</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body class="login-body">

<div class="container">

<div class="row justify-content-center align-items-center">

<div class="col-lg-5 col-md-7">

<div class="login-card fade-in">

<div class="text-center mb-4">

<i class="fa-solid fa-cloud fa-4x text-primary mb-3"></i>

<h2>AWS Cost Optimization</h2>

<p class="text-muted">

Intelligent Recommendation System

</p>

</div>

<?php if($success!=""){ ?>

<div class="alert alert-success">

<i class="fa-solid fa-circle-check"></i>

<?php echo $success; ?>

</div>

<?php } ?>

<?php if($error!=""){ ?>

<div class="alert alert-danger">

<i class="fa-solid fa-circle-exclamation"></i>

<?php echo $error; ?>

</div>

<?php } ?>

<form method="POST" autocomplete="off">

<div class="mb-3">

<label class="form-label">

Username

</label>

<div class="input-group">

<span class="input-group-text">

<i class="fa-solid fa-user"></i>

</span>

<input
type="text"
class="form-control"
name="username"
placeholder="Enter Username"
required>

</div>

</div>

<div class="mb-4">

<label class="form-label">

Password

</label>

<div class="input-group">

<span class="input-group-text">

<i class="fa-solid fa-lock"></i>

</span>

<input
type="password"
class="form-control"
name="password"
placeholder="Enter Password"
required>

</div>

</div>

<div class="d-grid">

<button type="submit" class="btn btn-primary btn-lg">

<i class="fa-solid fa-right-to-bracket"></i>

Login

</button>

</div>

</form>

<hr>

<div class="text-center">

<h6 class="text-muted mb-3">

Demo Credentials

</h6>

<p class="mb-2">

<strong>Username:</strong> admin

</p>

<p>

<strong>Password:</strong> admin123

</p>

</div>

</div>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>