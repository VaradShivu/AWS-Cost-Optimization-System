<?php

require "config/session.php";
require "classes/CsvProcessor.php";

$processor = new CsvProcessor("uploads/aws_cost.csv");

$totalCost = $processor->totalCost();
$totalRecords = $processor->totalRecords();
$averageCost = $processor->averageCost();

$highestService = $processor->highestCostService();
$highestCost = $processor->highestCost();

$serviceWise = $processor->serviceWiseCost();
$regionWise = $processor->regionWiseCost();

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<!-- ===========================
SIDEBAR
============================ -->

<div class="sidebar">

<h3>

<i class="fa-solid fa-cloud"></i>

AWS Cost

</h3>

<a class="active" href="dashboard.php">

<i class="fa-solid fa-house"></i>

Dashboard

</a>

<a href="upload.php">

<i class="fa-solid fa-upload"></i>

Upload CSV

</a>

<a href="analytics.php">

<i class="fa-solid fa-chart-column"></i>

Analytics

</a>

<a href="forecast.php">

<i class="fa-solid fa-chart-line"></i>

Forecast

</a>

<a href="anomaly.php">

<i class="fa-solid fa-triangle-exclamation"></i>

Anomaly Detection

</a>

<a href="recommendation.php">

<i class="fa-solid fa-lightbulb"></i>

Recommendations

</a>

<a href="governance.php">

<i class="fa-solid fa-shield-halved"></i>

Governance

</a>

<a href="reports.php">

<i class="fa-solid fa-file-pdf"></i>

Reports

</a>

<a href="logout.php">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

<!-- ===========================
MAIN
============================ -->

<div class="main">

<nav class="topbar">

<div>

<h4>

Welcome,

<?php echo $currentUser["name"]; ?>

👋

</h4>

</div>

<div>

<span class="badge bg-success">

System Online

</span>

</div>

</nav>

<div class="container-fluid mt-4">

<div class="row">

<!-- CARD 1 -->

<div class="col-lg-3 col-md-6">

<div class="dashboard-card blue">

<i class="fa-solid fa-indian-rupee-sign"></i>

<h5>

Total AWS Cost

</h5>

<h2>

₹<?php echo number_format($totalCost,2); ?>

</h2>

</div>

</div>

<!-- CARD 2 -->

<div class="col-lg-3 col-md-6">

<div class="dashboard-card green">

<i class="fa-solid fa-chart-simple"></i>

<h5>

Average Cost

</h5>

<h2>

₹<?php echo number_format($averageCost,2); ?>

</h2>

</div>

</div>

<!-- CARD 3 -->

<div class="col-lg-3 col-md-6">

<div class="dashboard-card orange">

<i class="fa-solid fa-database"></i>

<h5>

Total Records

</h5>

<h2>

<?php echo $totalRecords; ?>

</h2>

</div>

</div>

<!-- CARD 4 -->

<div class="col-lg-3 col-md-6">

<div class="dashboard-card red">

<i class="fa-solid fa-trophy"></i>

<h5>

Highest Service

</h5>

<h5>

<?php echo $highestService; ?>

</h5>

<p>

₹<?php echo number_format($highestCost,2); ?>

</p>

</div>

</div>

</div>

<!-- ===========================
Charts
============================ -->

<div class="row">

<div class="col-lg-8">

<div class="chart-box">

<h4>

Monthly Cost Trend

</h4>

<canvas id="costChart"></canvas>

</div>

</div>

<div class="col-lg-4">

<div class="chart-box">

<h4>

Service Distribution

</h4>

<canvas id="serviceChart"></canvas>

</div>

</div>

</div>

<!-- ===========================
Top Services
============================ -->

<div class="row mt-4">

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-server"></i>

Top AWS Services

</h4>

<table class="table table-hover">

<thead>

<tr>

<th>Service</th>

<th>Cost</th>

</tr>

</thead>

<tbody>

<?php

$count = 0;

foreach($serviceWise as $service => $cost)
{

    if($count==5)
        break;

?>

<tr>

<td>

<?php echo $service; ?>

</td>

<td>

₹<?php echo number_format($cost,2); ?>

</td>

</tr>

<?php

$count++;

}

?>

</tbody>

</table>

</div>

</div>

<!-- ===========================
Top Regions
============================ -->

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-earth-asia"></i>

Top Regions

</h4>

<table class="table table-hover">

<thead>

<tr>

<th>Region</th>

<th>Cost</th>

</tr>

</thead>

<tbody>

<?php

$count = 0;

foreach($regionWise as $region => $cost)
{

    if($count==5)
        break;

?>

<tr>

<td>

<?php echo $region; ?>

</td>

<td>

₹<?php echo number_format($cost,2); ?>

</td>

</tr>

<?php

$count++;

}

?>

</tbody>

</table>

</div>

</div>

</div>

<!-- ===========================
Recommendations
============================ -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-lightbulb text-warning"></i>

Cost Optimization Suggestions

</h4>

<div class="row">

<div class="col-md-4">

<div class="alert alert-primary">

<h5>

<i class="fa-solid fa-microchip"></i>

EC2 Recommendation

</h5>

<p>

Review EC2 instances with low CPU utilization.

Downsize idle instances to reduce costs.

</p>

</div>

</div>

<div class="col-md-4">

<div class="alert alert-success">

<h5>

<i class="fa-solid fa-box-archive"></i>

Storage Recommendation

</h5>

<p>

Move infrequently accessed S3 objects

to Glacier for lower storage costs.

</p>

</div>

</div>

<div class="col-md-4">

<div class="alert alert-warning">

<h5>

<i class="fa-solid fa-clock"></i>

Automation

</h5>

<p>

Automatically stop development servers

outside office hours.

</p>

</div>

</div>

</div>

</div>

</div>

</div>

<!-- ===========================
Quick Statistics
============================ -->

<div class="row mt-4">

<div class="col-lg-3">

<div class="dashboard-card purple">

<i class="fa-solid fa-cloud"></i>

<h5>

Services Used

</h5>

<h2>

<?php echo count($serviceWise); ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card blue">

<i class="fa-solid fa-location-dot"></i>

<h5>

Regions Used

</h5>

<h2>

<?php echo count($regionWise); ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card green">

<i class="fa-solid fa-file-csv"></i>

<h5>

CSV Status

</h5>

<h4>

Uploaded

</h4>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card orange">

<i class="fa-solid fa-rotate"></i>

<h5>

Last Refresh

</h5>

<h5>

<?php echo date("d M Y"); ?>

</h5>

</div>

</div>

</div>

<!-- ===========================
Footer
============================ -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box text-center">

<h5>

AWS Cost Optimization & Intelligent Recommendation System

</h5>

<p class="text-muted">

Developed using PHP, HTML, CSS, JavaScript & Chart.js

</p>

</div>

</div>

</div>

</div>

</div>

<?php

$serviceLabels = json_encode(array_keys($serviceWise));
$serviceValues = json_encode(array_values($serviceWise));

?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

const serviceLabels = <?php echo $serviceLabels; ?>;
const serviceValues = <?php echo $serviceValues; ?>;

const costChart = document.getElementById("costChart");

if(costChart){

new Chart(costChart,{

type:'bar',

data:{

labels:serviceLabels,

datasets:[{

label:'AWS Cost',

data:serviceValues,

borderWidth:1

}]

},

options:{

responsive:true,

plugins:{

legend:{

display:false

}

},

scales:{

y:{

beginAtZero:true

}

}

}

});

}

const pieChart = document.getElementById("serviceChart");

if(pieChart){

new Chart(pieChart,{

type:'pie',

data:{

labels:serviceLabels,

datasets:[{

data:serviceValues

}]

},

options:{

responsive:true

}

});

}

</script>

<script src="assets/js/script.js"></script>

</body>

</html>