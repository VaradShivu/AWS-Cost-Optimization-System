<?php

require "config/session.php";
require "classes/CsvProcessor.php";

$processor = new CsvProcessor("uploads/aws_cost.csv");

$totalCost = $processor->totalCost();
$averageCost = $processor->averageCost();
$serviceWise = $processor->serviceWiseCost();
$rows = $processor->getRows();

$avgCPU = $processor->averageCPU();
$avgStorage = $processor->averageStorage();
$avgRequests = $processor->averageRequests();

$estimatedSaving = $totalCost * 0.18;

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Recommendations</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="sidebar">

<h3>

<i class="fa-solid fa-cloud"></i>

AWS Cost

</h3>

<a href="dashboard.php">

<i class="fa-solid fa-house"></i>

Dashboard

</a>

<a href="upload.php">

<i class="fa-solid fa-upload"></i>

Upload CSV

</a>

<a href="analytics.php">

<i class="fa-solid fa-chart-column"></i>

Analytics

</a>

<a href="forecast.php">

<i class="fa-solid fa-chart-line"></i>

Forecast

</a>

<a href="anomaly.php">

<i class="fa-solid fa-triangle-exclamation"></i>

Anomaly Detection

</a>

<a class="active" href="recommendation.php">

<i class="fa-solid fa-lightbulb"></i>

Recommendations

</a>

<a href="governance.php">

<i class="fa-solid fa-shield-halved"></i>

Governance

</a>

<a href="reports.php">

<i class="fa-solid fa-file-pdf"></i>

Reports

</a>

<a href="logout.php">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

<div class="main">

<nav class="topbar">

<h4>

AWS Cost Optimization Recommendations

</h4>

</nav>

<div class="container-fluid mt-4">

<div class="row">

<div class="col-lg-3">

<div class="dashboard-card green">

<i class="fa-solid fa-piggy-bank"></i>

<h5>

Estimated Savings

</h5>

<h2>

₹<?php echo number_format($estimatedSaving,2); ?>

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card blue">

<i class="fa-solid fa-microchip"></i>

<h5>

Average CPU

</h5>

<h2>

<?php echo number_format($avgCPU,2); ?>%

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card orange">

<i class="fa-solid fa-hard-drive"></i>

<h5>

Average Storage

</h5>

<h2>

<?php echo number_format($avgStorage,2); ?> GB

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card red">

<i class="fa-solid fa-network-wired"></i>

<h5>

Average Requests

</h5>

<h2>

<?php echo number_format($avgRequests,0); ?>

</h2>

</div>

</div>

</div>

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-lightbulb text-warning"></i>

Optimization Opportunities

</h4>

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>Category</th>

<th>Recommendation</th>

<th>Expected Impact</th>

</tr>

</thead>

<tbody>

<tr>

<td>EC2</td>

<td>Resize low-utilization EC2 instances.</td>

<td>High</td>

</tr>

<tr>

<td>S3</td>

<td>Move old objects to Glacier.</td>

<td>Medium</td>

</tr>

<tr>

<td>EBS</td>

<td>Delete unattached volumes.</td>

<td>High</td>

</tr>

<tr>

<td>Auto Scaling</td>

<td>Scale resources based on demand.</td>

<td>High</td>

</tr>

<tr>

<td>Reserved Instances</td>

<td>Purchase RI for long-running workloads.</td>

<td>Very High</td>

</tr>

</tbody>

</table>

</div>

</div>

</div>

<!-- ==========================================
SMART RECOMMENDATIONS
========================================== -->

<div class="row mt-4">

<div class="col-lg-4">

<div class="alert alert-success">

<h5>

<i class="fa-solid fa-server"></i>

Compute Optimization

</h5>

<p>

<?php

if($avgCPU < 30)
{
    echo "CPU utilization is low. Consider downsizing EC2 instances to reduce costs.";
}
elseif($avgCPU < 70)
{
    echo "CPU utilization is healthy. Continue monitoring workload trends.";
}
else
{
    echo "CPU utilization is high. Enable Auto Scaling or upgrade instances.";
}

?>

</p>

</div>

</div>

<div class="col-lg-4">

<div class="alert alert-warning">

<h5>

<i class="fa-solid fa-hard-drive"></i>

Storage Optimization

</h5>

<p>

<?php

if($avgStorage > 300)
{
    echo "Storage consumption is high. Archive unused data to Amazon Glacier.";
}
else
{
    echo "Storage usage is within the normal range.";
}

?>

</p>

</div>

</div>

<div class="col-lg-4">

<div class="alert alert-info">

<h5>

<i class="fa-solid fa-wallet"></i>

Billing Recommendation

</h5>

<p>

Purchase Reserved Instances or Savings Plans for long-running workloads to reduce compute expenses.

</p>

</div>

</div>

</div>

<!-- ==========================================
TOP EXPENSIVE SERVICES
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-coins"></i>

Top Costly AWS Services

</h4>

<table class="table table-hover table-bordered">

<thead>

<tr>

<th>Rank</th>

<th>Service</th>

<th>Total Cost</th>

<th>Recommendation</th>

</tr>

</thead>

<tbody>

<?php

$rank = 1;

foreach($serviceWise as $service=>$cost)
{

if($rank>10)
break;

?>

<tr>

<td>

<?php echo $rank; ?>

</td>

<td>

<?php echo $service; ?>

</td>

<td>

₹<?php echo number_format($cost,2); ?>

</td>

<td>

<?php

switch(strtolower($service))
{

case "ec2":

echo "Use Reserved Instances / Auto Scaling";

break;

case "s3":

echo "Move old data to Glacier";

break;

case "rds":

echo "Stop unused databases";

break;

case "lambda":

echo "Optimize execution time";

break;

default:

echo "Review service utilization";

}

?>

</td>

</tr>

<?php

$rank++;

}

?>

</tbody>

</table>

</div>

</div>

</div>

<!-- ==========================================
GREEN COMPUTING
========================================== -->

<div class="row mt-4">

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-leaf text-success"></i>

Green Computing Suggestions

</h4>

<ul class="list-group">

<li class="list-group-item">

Delete unused snapshots and EBS volumes.

</li>

<li class="list-group-item">

Terminate idle EC2 instances.

</li>

<li class="list-group-item">

Enable automatic shutdown outside office hours.

</li>

<li class="list-group-item">

Move archive data to Glacier.

</li>

<li class="list-group-item">

Use Auto Scaling Groups.

</li>

</ul>

</div>

</div>

<!-- ==========================================
PRIORITY MATRIX
========================================== -->

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-list-check"></i>

Cost Saving Priority

</h4>

<table class="table table-bordered">

<thead>

<tr>

<th>Priority</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<tr>

<td>

<span class="badge bg-danger">

High

</span>

</td>

<td>

Review EC2 Compute Costs

</td>

</tr>

<tr>

<td>

<span class="badge bg-warning text-dark">

Medium

</span>

</td>

<td>

Optimize Storage

</td>

</tr>

<tr>

<td>

<span class="badge bg-primary">

Medium

</span>

</td>

<td>

Purchase Reserved Instances

</td>

</tr>

<tr>

<td>

<span class="badge bg-success">

Low

</span>

</td>

<td>

Monitor Monthly Billing

</td>

</tr>

</tbody>

</table>

</div>

</div>

</div>

<!-- ==========================================
ESTIMATED SAVINGS
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-sack-dollar"></i>

Estimated Monthly Savings

</h4>

<table class="table table-striped">

<thead>

<tr>

<th>Optimization</th>

<th>Estimated Saving</th>

</tr>

</thead>

<tbody>

<tr>

<td>

EC2 Rightsizing

</td>

<td>

₹<?php echo number_format($estimatedSaving*0.45,2); ?>

</td>

</tr>

<tr>

<td>

Storage Optimization

</td>

<td>

₹<?php echo number_format($estimatedSaving*0.25,2); ?>

</td>

</tr>

<tr>

<td>

Reserved Instances

</td>

<td>

₹<?php echo number_format($estimatedSaving*0.20,2); ?>

</td>

</tr>

<tr>

<td>

Unused Resources Cleanup

</td>

<td>

₹<?php echo number_format($estimatedSaving*0.10,2); ?>

</td>

</tr>

</tbody>

</table>

</div>

</div>

</div>

<!-- ==========================================
RECOMMENDATION SUMMARY CHART
========================================== -->

<div class="row mt-4">

<div class="col-lg-8">

<div class="chart-box">

<h4>

<i class="fa-solid fa-chart-column"></i>

Estimated Savings Distribution

</h4>

<canvas id="savingChart"></canvas>

</div>

</div>

<div class="col-lg-4">

<div class="chart-box">

<h4>

<i class="fa-solid fa-chart-pie"></i>

Optimization Categories

</h4>

<canvas id="categoryChart"></canvas>

</div>

</div>

</div>

<!-- ==========================================
FINAL SUMMARY
========================================== -->

<div class="row mt-4">

<div class="col-lg-4">

<div class="alert alert-success text-center">

<h5>

Estimated Monthly Saving

</h5>

<h2>

₹<?php echo number_format($estimatedSaving,2); ?>

</h2>

</div>

</div>

<div class="col-lg-4">

<div class="alert alert-primary text-center">

<h5>

Optimization Opportunities

</h5>

<h2>

<?php echo count($serviceWise); ?>

</h2>

</div>

</div>

<div class="col-lg-4">

<div class="alert alert-warning text-center">

<h5>

Recommendation Status

</h5>

<h2>

Ready

</h2>

</div>

</div>

</div>

<!-- ==========================================
FOOTER
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box text-center">

<h5>

AWS Cost Optimization & Intelligent Recommendation System

</h5>

<p class="text-muted">

Recommendation Engine • Based on uploaded AWS Billing CSV

</p>

</div>

</div>

</div>

</div>

</div>

<?php

$savingLabels = json_encode([
    "EC2 Rightsizing",
    "Storage",
    "Reserved Instances",
    "Cleanup"
]);

$savingValues = json_encode([
    round($estimatedSaving * 0.45,2),
    round($estimatedSaving * 0.25,2),
    round($estimatedSaving * 0.20,2),
    round($estimatedSaving * 0.10,2)
]);

$categoryLabels = json_encode([
    "Compute",
    "Storage",
    "Database",
    "Networking"
]);

$categoryValues = json_encode([
    40,
    25,
    20,
    15
]);

?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

// ========================================
// Savings Bar Chart
// ========================================

const savingCanvas = document.getElementById("savingChart");

if(savingCanvas){

new Chart(savingCanvas,{

type:"bar",

data:{

labels:<?php echo $savingLabels; ?>,

datasets:[{

label:"Estimated Savings (₹)",

data:<?php echo $savingValues; ?>,

borderWidth:1

}]

},

options:{

responsive:true,

plugins:{

legend:{

display:false

}

},

scales:{

y:{

beginAtZero:true

}

}

}

});

}

// ========================================
// Category Pie Chart
// ========================================

const categoryCanvas = document.getElementById("categoryChart");

if(categoryCanvas){

new Chart(categoryCanvas,{

type:"pie",

data:{

labels:<?php echo $categoryLabels; ?>,

datasets:[{

data:<?php echo $categoryValues; ?>

}]

},

options:{

responsive:true

}

});

}

</script>

<script src="assets/js/script.js"></script>

</body>

</html>