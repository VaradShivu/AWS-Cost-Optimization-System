<?php

require "config/session.php";
require "classes/CsvProcessor.php";

$processor = new CsvProcessor("uploads/aws_cost.csv");

$totalCost = $processor->totalCost();
$totalRecords = $processor->totalRecords();

$avgCPU = $processor->averageCPU();
$avgStorage = $processor->averageStorage();

$serviceWise = $processor->serviceWiseCost();

$complianceScore = 92;

$budgetScore = ($totalCost < 100000) ? 95 : 70;
$securityScore = 90;
$resourceScore = ($avgCPU < 75) ? 93 : 78;

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>AWS Governance</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="sidebar">

<h3>

<i class="fa-solid fa-cloud"></i>

AWS Cost

</h3>

<a href="dashboard.php">

<i class="fa-solid fa-house"></i>

Dashboard

</a>

<a href="upload.php">

<i class="fa-solid fa-upload"></i>

Upload CSV

</a>

<a href="analytics.php">

<i class="fa-solid fa-chart-column"></i>

Analytics

</a>

<a href="forecast.php">

<i class="fa-solid fa-chart-line"></i>

Forecast

</a>

<a href="anomaly.php">

<i class="fa-solid fa-triangle-exclamation"></i>

Anomaly Detection

</a>

<a href="recommendation.php">

<i class="fa-solid fa-lightbulb"></i>

Recommendations

</a>

<a class="active" href="governance.php">

<i class="fa-solid fa-shield-halved"></i>

Governance

</a>

<a href="reports.php">

<i class="fa-solid fa-file-pdf"></i>

Reports

</a>

<a href="logout.php">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

<div class="main">

<nav class="topbar">

<h4>

AWS Governance Dashboard

</h4>

</nav>

<div class="container-fluid mt-4">

<div class="row">

<div class="col-lg-3">

<div class="dashboard-card green">

<i class="fa-solid fa-shield-check"></i>

<h5>

Compliance Score

</h5>

<h2>

<?php echo $complianceScore; ?>%

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card blue">

<i class="fa-solid fa-wallet"></i>

<h5>

Budget Score

</h5>

<h2>

<?php echo $budgetScore; ?>%

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card orange">

<i class="fa-solid fa-lock"></i>

<h5>

Security Score

</h5>

<h2>

<?php echo $securityScore; ?>%

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="dashboard-card red">

<i class="fa-solid fa-server"></i>

<h5>

Resource Score

</h5>

<h2>

<?php echo $resourceScore; ?>%

</h2>

</div>

</div>

</div>

<div class="row mt-4">

<div class="col-lg-8">

<div class="chart-box">

<h4>

Governance Compliance

</h4>

<canvas id="governanceChart"></canvas>

</div>

</div>

<div class="col-lg-4">

<div class="chart-box">

<h4>

Governance Summary

</h4>

<ul class="list-group">

<li class="list-group-item">

Total Resources

<span class="float-end">

<?php echo $totalRecords; ?>

</span>

</li>

<li class="list-group-item">

Average CPU

<span class="float-end">

<?php echo number_format($avgCPU,2); ?>%

</span>

</li>

<li class="list-group-item">

Average Storage

<span class="float-end">

<?php echo number_format($avgStorage,2); ?>

GB

</span>

</li>

<li class="list-group-item">

AWS Services

<span class="float-end">

<?php echo count($serviceWise); ?>

</span>

</li>

</ul>

</div>

</div>

</div>

<!-- ==========================================
GOVERNANCE VIOLATIONS
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-triangle-exclamation text-danger"></i>

Governance Violations

</h4>

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>ID</th>

<th>Category</th>

<th>Description</th>

<th>Severity</th>

<th>Status</th>

</tr>

</thead>

<tbody>

<tr>

<td>GV-001</td>

<td>Compute</td>

<td>EC2 instances running with low utilization.</td>

<td>

<span class="badge bg-danger">

High

</span>

</td>

<td>

Open

</td>

</tr>

<tr>

<td>GV-002</td>

<td>Storage</td>

<td>Unused EBS volumes detected.</td>

<td>

<span class="badge bg-warning text-dark">

Medium

</span>

</td>

<td>

Open

</td>

</tr>

<tr>

<td>GV-003</td>

<td>S3</td>

<td>Objects not transitioned to Glacier.</td>

<td>

<span class="badge bg-primary">

Medium

</span>

</td>

<td>

Review

</td>

</tr>

<tr>

<td>GV-004</td>

<td>Security</td>

<td>IAM users without MFA enabled.</td>

<td>

<span class="badge bg-danger">

High

</span>

</td>

<td>

Review

</td>

</tr>

<tr>

<td>GV-005</td>

<td>Budget</td>

<td>Billing alerts not configured.</td>

<td>

<span class="badge bg-warning text-dark">

Medium

</span>

</td>

<td>

Pending

</td>

</tr>

</tbody>

</table>

</div>

</div>

</div>

<!-- ==========================================
COMPLIANCE CHECKLIST
========================================== -->

<div class="row mt-4">

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-list-check text-success"></i>

Compliance Checklist

</h4>

<table class="table table-bordered">

<tbody>

<tr>

<td>

AWS Budgets Configured

</td>

<td>

<span class="badge bg-success">

Yes

</span>

</td>

</tr>

<tr>

<td>

Billing Alerts Enabled

</td>

<td>

<span class="badge bg-warning text-dark">

No

</span>

</td>

</tr>

<tr>

<td>

Auto Scaling Enabled

</td>

<td>

<span class="badge bg-success">

Yes

</span>

</td>

</tr>

<tr>

<td>

Unused Resources Reviewed

</td>

<td>

<span class="badge bg-danger">

Pending

</span>

</td>

</tr>

<tr>

<td>

Cost Allocation Tags

</td>

<td>

<span class="badge bg-success">

Configured

</span>

</td>

</tr>

<tr>

<td>

MFA Enabled

</td>

<td>

<span class="badge bg-warning text-dark">

Partial

</span>

</td>

</tr>

</tbody>

</table>

</div>

</div>

<!-- ==========================================
SECURITY RECOMMENDATIONS
========================================== -->

<div class="col-lg-6">

<div class="chart-box">

<h4>

<i class="fa-solid fa-lock text-primary"></i>

Security Recommendations

</h4>

<div class="alert alert-info">

<ul class="mb-0">

<li>Enable Multi-Factor Authentication (MFA).</li>

<li>Rotate IAM access keys regularly.</li>

<li>Remove unused IAM users and roles.</li>

<li>Enable CloudTrail logging.</li>

<li>Review security groups for open ports.</li>

<li>Encrypt EBS volumes and S3 buckets.</li>

</ul>

</div>

</div>

</div>

</div>

<!-- ==========================================
RESOURCE GOVERNANCE
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box">

<h4>

<i class="fa-solid fa-server"></i>

Resource Governance Recommendations

</h4>

<div class="row">

<div class="col-md-3">

<div class="alert alert-success text-center">

<h5>

Compute

</h5>

<p>

Optimize EC2 sizing.

</p>

</div>

</div>

<div class="col-md-3">

<div class="alert alert-warning text-center">

<h5>

Storage

</h5>

<p>

Archive unused data.

</p>

</div>

</div>

<div class="col-md-3">

<div class="alert alert-primary text-center">

<h5>

Networking

</h5>

<p>

Review idle Load Balancers.

</p>

</div>

</div>

<div class="col-md-3">

<div class="alert alert-danger text-center">

<h5>

Cost

</h5>

<p>

Monitor budget daily.

</p>

</div>

</div>

</div>

</div>

</div>

</div>

<!-- ==========================================
GOVERNANCE DASHBOARD SUMMARY
========================================== -->

<div class="row mt-4">

<div class="col-lg-8">

<div class="chart-box">

<h4>

<i class="fa-solid fa-chart-column"></i>

Governance Score Distribution

</h4>

<canvas id="governanceChart"></canvas>

</div>

</div>

<div class="col-lg-4">

<div class="chart-box">

<h4>

<i class="fa-solid fa-chart-pie"></i>

Compliance Overview

</h4>

<canvas id="complianceChart"></canvas>

</div>

</div>

</div>

<!-- ==========================================
FINAL GOVERNANCE STATUS
========================================== -->

<div class="row mt-4">

<div class="col-lg-3">

<div class="alert alert-success text-center">

<h5>

Compliance

</h5>

<h2>

<?php echo $complianceScore; ?>%

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="alert alert-primary text-center">

<h5>

Budget Health

</h5>

<h2>

<?php echo $budgetScore; ?>%

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="alert alert-warning text-center">

<h5>

Security

</h5>

<h2>

<?php echo $securityScore; ?>%

</h2>

</div>

</div>

<div class="col-lg-3">

<div class="alert alert-danger text-center">

<h5>

Resources

</h5>

<h2>

<?php echo $resourceScore; ?>%

</h2>

</div>

</div>

</div>

<!-- ==========================================
FOOTER
========================================== -->

<div class="row mt-4">

<div class="col-lg-12">

<div class="chart-box text-center">

<h5>

AWS Cost Optimization & Intelligent Recommendation System

</h5>

<p class="text-muted">

Governance Module • Compliance & Best Practice Monitoring

</p>

</div>

</div>

</div>

</div>

</div>

<?php

$governanceLabels = json_encode([
    "Compliance",
    "Budget",
    "Security",
    "Resources"
]);

$governanceValues = json_encode([
    $complianceScore,
    $budgetScore,
    $securityScore,
    $resourceScore
]);

$compliancePieLabels = json_encode([
    "Compliant",
    "Needs Review"
]);

$compliancePieValues = json_encode([
    $complianceScore,
    100 - $complianceScore
]);

?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

// ==========================================
// Governance Score Chart
// ==========================================

const governanceCanvas = document.getElementById("governanceChart");

if(governanceCanvas){

new Chart(governanceCanvas,{

type:"bar",

data:{

labels:<?php echo $governanceLabels; ?>,

datasets:[{

label:"Governance Score",

data:<?php echo $governanceValues; ?>,

borderWidth:1

}]

},

options:{

responsive:true,

plugins:{

legend:{

display:false

}

},

scales:{

y:{

beginAtZero:true,

max:100

}

}

}

});

}

// ==========================================
// Compliance Pie Chart
// ==========================================

const complianceCanvas = document.getElementById("complianceChart");

if(complianceCanvas){

new Chart(complianceCanvas,{

type:"doughnut",

data:{

labels:<?php echo $compliancePieLabels; ?>,

datasets:[{

data:<?php echo $compliancePieValues; ?>

}]

},

options:{

responsive:true,

cutout:"65%"

}

});

}

</script>

<script src="assets/js/script.js"></script>

</body>

</html>